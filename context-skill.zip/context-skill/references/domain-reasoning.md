# Domain Reasoning — Reference

This file contains the domain reasoning prompt and domain reference library used to
generate Output 2 (domain-specific follow-up questions).

---

## Domain reasoning prompt

When generating domain-specific questions, follow this process:

### 1. Identify the domain(s)
From the General Context Brief, identify the primary and any secondary domains.

### 2. Assess gaps
Read every answer. Find what's missing that a domain expert would need to know:
- Domain-specific terminology, standards, or conventions
- Common pitfalls the user hasn't mentioned
- Domain-specific assets, references, or resources
- Regulatory, compliance, or quality requirements
- Established tools, formats, or workflows to align with

### 3. Generate questions
MAXIMUM 10 questions. Aim for 3-7. Each must:
- Be something the universal form would NOT have covered
- Be directly relevant to improving skill quality
- Include a WHY explanation (1 sentence, conversational)
- Include a concrete placeholder example
- Be tagged: ESSENTIAL, RECOMMENDED, or OPTIONAL
- Be grouped under domain-relevant category headings

---

## Domain reference library

Use these as inspiration, NOT a checklist. Only ask what's relevant.

### Creative & content domains
- Brand voice and tone documentation
- Target audience personas and demographics
- Platform-specific requirements (character limits, image dimensions, algorithm preferences)
- Content approval workflows
- Brand assets (logos, colour palettes, fonts, image libraries)
- Competitor references (what to emulate, what to avoid)
- Legal/compliance requirements (disclaimers, regulated claims, accessibility)
- Content calendar or publishing cadence
- Performance metrics and KPIs

### Analytical & financial domains
- Reporting standards and frameworks (IFRS, GAAP, CIMA, etc.)
- Data sources and refresh frequencies
- Calculation methodologies and formulas
- Rounding rules and precision requirements
- Currency and unit conventions
- Benchmark or comparison data expectations
- Variance thresholds and materiality levels
- Stakeholder audience (board, management, operational)
- Chart/visualisation conventions

### Scientific & technical domains
- Measurement protocols and equipment specifications
- Sampling rates, thresholds, and calibration standards
- Statistical methods and significance levels
- Data collection procedures and file formats
- Ethical approval or regulatory requirements
- Peer review or validation workflows
- Domain-specific terminology and abbreviations
- Reference databases or normative data sets

### Software & development domains
- Tech stack and language preferences
- Code style guides and linting rules
- Repository structure and naming conventions
- Testing frameworks and coverage requirements
- CI/CD pipeline conventions
- Security and authentication patterns
- API design standards (REST, GraphQL, etc.)
- Documentation conventions

### Operational & process domains
- Workflow tools and platforms in use
- Approval chains and decision authority
- Template or document standards
- Compliance and regulatory frameworks
- Role-based access or visibility requirements
- Escalation procedures
- Training or onboarding context
- Integration points with other systems

### Cross-domain considerations
- Localisation (language, region, cultural context)
- Accessibility requirements
- Version control or audit trail needs
- Multi-user or collaborative workflows
- Integration with existing tools or MCP servers
- Frequency of use (daily, weekly, ad-hoc)
- Evolution expectations (will this skill grow over time?)

---

## Output 2 form rendering

The domain-specific questions MUST be rendered as an interactive HTML widget matching
the exact visual style of the Output 1 form. Differences from Output 1:

### Intro card
Before the first section, show a brief card with:
- Title: "Domain-specific context"
- Subtitle: the identified domain(s)
- 2-3 sentence assessment of what's covered and what gaps were found

### Priority badges
Each question label includes a small pill badge after the text:
- ESSENTIAL: `background: #EEEDFE; color: #534AB7; font-size: 11px; padding: 2px 8px;
  border-radius: 10px; font-weight: 500; margin-left: 8px;`
- RECOMMENDED: `background: #E1F5EE; color: #0F6E56; font-size: 11px; padding: 2px 8px;
  border-radius: 10px; font-weight: 500; margin-left: 8px;`
- OPTIONAL: `background: #F1EFE8; color: #5F5E5A; font-size: 11px; padding: 2px 8px;
  border-radius: 10px; font-weight: 500; margin-left: 8px;`

### WHY line
Below each label and above the textarea, show the "why this matters" line:
`font-size: 13px; color: var(--color-text-secondary); font-style: italic; margin: 4px 0 8px;`

### Export button
Text reads "Generate full context brief ↗" instead of "Generate context brief".

### Export payload
The `sendPrompt()` payload must include BOTH Output 1 and Output 2 answers:

```
Here is my completed context (General + Domain-Specific). Please compile the full
Skill Context Brief (Output 3) and present the skill summary for my review.

GENERAL CONTEXT (Output 1)
===========================
[all 16 general answers]

DOMAIN-SPECIFIC CONTEXT (Output 2)
====================================
Domain: [identified domain]
Complexity: [assessed complexity]

[Category 1]
[question]: [answer]
[question]: [answer]

[Category 2]
[question]: [answer]
...
```

### Passing Output 1 answers through

The Output 2 form needs access to the Output 1 answers so it can include them in the
export. When rendering the Output 2 form, embed the Output 1 brief as a hidden data
attribute or JS variable within the widget so the export function can concatenate both.
