# Intake Interaction Flow — Reference

This file contains the logic layer that governs how the Context Skill moves between
Output 1 and Output 2. It handles brief analysis, intelligent branching, deduplication,
and adaptive skipping.

---

## 1. Brief analysis

When the General Context Brief arrives, classify each of the 16 answers:

- **Rich** — Detailed, specific, concrete examples. No follow-up needed.
- **Thin** — Short or vague, lacks specificity. Candidate for domain-specific probing.
- **Empty** — Blank, "N/A", or "not sure". Revisit in domain form but reframed.

Then extract:
- **Primary domain** — from Q1 (purpose) and Q6 (inputs)
- **Secondary domains** — any adjacent fields the skill touches
- **User expertise level** — from Q3 vocabulary and detail level across all answers
- **Skill complexity** — Simple (single input→output), Moderate (multi-step, some edge
  cases), or Complex (conditional logic, multiple outputs, many edge cases)

---

## 2. Skip decision

**Skip Output 2 entirely if ALL true:**
- Most answers (12+) are Rich
- Skill complexity is Simple
- No domain-specific gaps identified (no standards, conventions, or terminology missing)

Tell the user: "Your context brief is thorough enough — no domain-specific follow-up
needed. I'm compiling the full brief now."

**Generate Output 2 if ANY true:**
- 3+ answers are Thin or Empty on important dimensions (inputs, outputs, process, standards)
- The domain has standards/conventions/terminology not yet captured
- Domain-specific assets, references, or tools are likely needed
- Skill complexity is Moderate or Complex

---

## 3. Branching rules — digging deeper

### Input branching
- Q6 mentions files but Q7 is thin → ask for exact file structure in domain terms
- Q6 mentions images/visual assets → ask about resolution, format, brand assets
- Q6 is "conversational prompt" with no files → skill is simpler, fewer follow-ups needed

### Output branching
- Q8 specifies file type but Q9 is thin → ask for concrete output example in domain terms
- Q10 is empty/vague → reframe as domain pitfall: "What's the most common mistake when
  doing this task manually?"

### Process branching
- Q11 says "Claude should have freedom" → ask about guardrails and approaches to avoid
- Q11 lists detailed steps → ask about failure handling: "If step 3 fails, what happens?"

### Constraint branching
- Q12 mentions a specific standard → ask if they can provide the reference document or
  summary of key rules
- Q13 is empty → suggest 2-3 likely edge cases based on domain and ask user to confirm

---

## 4. Deduplication rules

### Hard deduplication
Before including any domain question, check it against every Output 1 answer. If the
information is already there — even partially — drop the question.

**Test:** Can you answer the proposed domain question using existing answers? If yes, it's
a duplicate.

### Reframe, don't repeat
If a general answer was thin, the domain question MUST be framed differently.

**Bad:** Q7 was thin. Domain form asks "Can you describe your input data structure?"
(This is a repeat — user will be annoyed.)

**Good:** Q7 was thin. Domain form asks "Your financial reports — are they structured as
a single summary sheet or multiple tabs per department? And do they use formulas or just
static values?" (This digs deeper with domain-specific framing.)

### Cross-reference matrix

| Domain question about... | Check general Q... | Only ask if... |
|---|---|---|
| File structure / data layout | Q6, Q7 | Format details missing |
| Quality criteria | Q9, Q10 | Domain-specific quality not addressed |
| Workflow steps | Q11 | Domain-specific steps missing |
| Standards / rules | Q12 | Specific standard details not provided |
| Error handling / edge cases | Q13, Q14 | Domain-specific pitfalls not mentioned |
| Success measurement | Q15 | Domain-specific KPIs not covered |

---

## 5. Adaptive skipping

### Question count by complexity

| Complexity | Typical domain questions |
|---|---|
| Simple | 0 (skip to Output 3) |
| Moderate | 3-5 |
| Complex | 6-10 |

Never pad. If 4 questions cover the gaps, ask 4.

### Section skipping within Output 2
If some domain categories are fully covered by Output 1, don't render those sections.
Only show sections with genuine gaps.

---

## 6. Transition messaging

**Moving to Output 2:**
"Thanks for filling that out. Based on what you've described, this sits in [domain].
There are a few [domain]-specific details that'll make the skill noticeably better.
I've got [N] follow-up questions — shouldn't take long."

**Skipping to Output 3:**
"Your brief covers everything we need. I'm compiling the full context document now —
you can pass this straight to the skill-creator."

---

## 7. Suggested edge cases

When Q13 was empty, don't repeat "what are the edge cases?" — use domain knowledge
to SUGGEST likely edge cases and ask the user to confirm or dismiss.

Example for biomechanics: "Based on your description, these scenarios might cause
issues: (1) a trial where the force plate doesn't register initial contact cleanly,
(2) a participant with an unusually high or low baseline, (3) missing data in one or
more columns. Do any of these apply?"

Example for marketing: "A few things that commonly trip up content skills: (1) posts
that need to reference time-sensitive promotions, (2) products with very similar
descriptions leading to repetitive copy, (3) platform algorithm changes. Relevant?"
