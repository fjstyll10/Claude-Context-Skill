# General Context Form — Output 1 Reference

This file contains the complete specification for the General Context Form: all 16 questions,
section introductions, placeholder examples, and the HTML rendering pattern.

---

## Form structure

7 sections, 16 questions. Navigated section-by-section with a progress bar.

### Section 1: Skill purpose & identity

**Intro:** "Let's start with the big picture. Understanding what the skill does and why it
exists helps Claude grasp the intent behind the instructions — not just the mechanics."

| ID | Label | Placeholder |
|----|-------|-------------|
| q1 | What should this skill do? | Describe in plain language the task or workflow it handles. E.g. 'Generate weekly social media content calendars for a fitness brand.' |
| q2 | Why does this skill need to exist? | What problem does it solve or what repetitive task does it eliminate? E.g. 'I spend 2 hours every Monday planning posts manually.' |
| q3 | Who is the end user? | Is this for you personally, a team, a specific role? What's their technical level? E.g. 'Marketing manager, non-technical, uses Claude casually.' |

### Section 2: Trigger & activation

**Intro:** "This is arguably the most important section. A skill that doesn't trigger at the
right time is a skill that doesn't get used. We need to know exactly when it should — and
shouldn't — kick in."

| ID | Label | Placeholder |
|----|-------|-------------|
| q4 | When should this skill activate? | What phrases, keywords, or situations should trigger it? E.g. 'When someone mentions content calendar, social media plan, or weekly posts.' |
| q5 | When should this skill NOT activate? | Are there similar-sounding requests where this skill would be the wrong choice? E.g. 'Not for one-off caption writing or ad copy.' |

### Section 3: Inputs

**Intro:** "Knowing what goes into the skill — file types, data formats, structure — means
Claude won't have to guess. The more specific you are here, the fewer errors you'll get."

| ID | Label | Placeholder |
|----|-------|-------------|
| q6 | What inputs does the skill need? | Files (what type/format?), text, images, data, URLs, or just a conversational prompt? E.g. 'A .csv of product names and a brand voice document (.pdf).' |
| q7 | What does the input data look like? | Describe structure, layout, column names, expected formats. E.g. 'CSV with columns: product_name, category, price, description. Usually 20-50 rows.' |

### Section 4: Outputs

**Intro:** "Defining what good and bad look like gives Claude a target to aim for and pitfalls
to avoid. This is where vague skills become precise ones."

| ID | Label | Placeholder |
|----|-------|-------------|
| q8 | What is the expected output? | A file (docx, xlsx, pdf, html, etc.), a conversational response, a visualisation, structured data? E.g. 'A .xlsx content calendar with columns for date, platform, copy, hashtags, and image brief.' |
| q9 | What does a good output look like? | Describe or give an example of the ideal result. E.g. '7 days of posts, each with platform-specific copy, 3-5 hashtags, and a one-line image description.' |
| q10 | What does a bad output look like? | What would make the output fail or be unusable? E.g. 'Generic copy that doesn't match our brand voice, missing dates, or duplicate posts across platforms.' |

### Section 5: Process & logic

**Intro:** "Some skills need a strict step-by-step workflow. Others work best when Claude has
creative freedom. This section tells us which approach fits."

| ID | Label | Placeholder |
|----|-------|-------------|
| q11 | Are there specific steps the skill must follow? | Is there a defined workflow or sequence, or should Claude have freedom to approach it however works best? E.g. '1. Read brand doc 2. Parse product CSV 3. Generate 7-day calendar 4. Format as xlsx.' |
| q12 | Are there rules, standards, or conventions it must follow? | Industry standards, company rules, regulatory requirements, style guides? E.g. 'Must follow our tone-of-voice guide: casual, no jargon, always inclusive.' |

### Section 6: Constraints & edge cases

**Intro:** "This is where most skills quietly break. Thinking about what could go wrong now
saves a lot of debugging later."

| ID | Label | Placeholder |
|----|-------|-------------|
| q13 | What are the known edge cases or tricky scenarios? | Situations where the skill might break or produce unexpected results. E.g. 'If the CSV has empty product descriptions, the copy ends up generic.' |
| q14 | Are there any hard constraints? | File size limits, character counts, specific tools/libraries, privacy requirements? E.g. 'Output must be under 50 rows. No external API calls. No customer PII in outputs.' |

### Section 7: Success criteria

**Intro:** "Finally, how do we know it's working? Defining success upfront means we can test
the skill properly and iterate with purpose."

| ID | Label | Placeholder |
|----|-------|-------------|
| q15 | How will you know the skill is working well? | Is it objectively measurable (correct data extraction) or subjective (good writing quality)? E.g. 'Every row has a date, platform, copy, and hashtags. Copy matches brand voice on first pass.' |
| q16 | What's the minimum viable version? | If we shipped a basic version today, what's the one thing it absolutely must do? E.g. 'Generate 7 days of Instagram captions from a product list — everything else is a bonus.' |

---

## HTML rendering specification

Render the form as an interactive HTML widget via the `show_widget` tool. The form must:

1. Show a **sticky progress bar** at the top with section count ("Section 1 of 7") and
   completion percentage based on how many textareas have content.

2. Display **one section at a time** with Previous/Next navigation buttons.

3. Each section starts with its **title** (18px, weight 500) and **intro paragraph**
   (14px, secondary colour, 1.6 line-height).

4. Each question is a **label** (14px, weight 500) above a **textarea** (min-height 90px,
   resizable, 14px, 1.55 line-height) with the placeholder text.

5. The final section shows a **"Generate context brief"** button instead of "Next". This
   button compiles all textarea values into a structured text payload and sends it via
   `sendPrompt()`.

6. Use CSS variables for all colours (`--color-text-primary`, `--color-text-secondary`,
   `--color-border-tertiary`, `--color-background-primary`, etc.) to support light/dark mode.

7. No external dependencies. Pure HTML/CSS/JS.

8. Max width 640px. Padding 1.5rem 0.

### Export format

When the user clicks "Generate context brief", the `sendPrompt()` payload should be:

```
Here is my completed General Context Brief. Please review it and then generate the
domain-specific follow-up questions (Output 2).

GENERAL CONTEXT BRIEF
=====================

## SKILL PURPOSE & IDENTITY

What should this skill do?
[answer]

Why does this skill need to exist?
[answer]

Who is the end user?
[answer]

## TRIGGER & ACTIVATION

When should this skill activate?
[answer]

When should this skill NOT activate?
[answer]

[...continue for all 7 sections and 16 questions...]
```

### Reference HTML pattern

Use this pattern for the form structure (adapt as needed, this is the architectural
pattern, not a rigid template):

```html
<div style="max-width: 640px; padding: 1.5rem 0;">

  <!-- Sticky progress bar -->
  <div style="position: sticky; top: 0; z-index: 10; background: var(--color-background-primary);
    padding: 12px 0 16px; border-bottom: 0.5px solid var(--color-border-tertiary); margin-bottom: 1.5rem;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
      <span style="font-size: 13px; color: var(--color-text-secondary);" id="progress-label">Section 1 of 7</span>
      <span style="font-size: 13px; font-weight: 500;" id="progress-pct">0% complete</span>
    </div>
    <div style="height: 4px; background: var(--color-background-tertiary); border-radius: 2px; overflow: hidden;">
      <div id="progress-fill" style="height: 100%; width: 0%; background: #534AB7; border-radius: 2px;
        transition: width 0.4s ease;"></div>
    </div>
  </div>

  <!-- Sections container (JS builds sections here) -->
  <div id="sections-container"></div>

  <!-- Navigation -->
  <div style="display: flex; gap: 12px; margin-top: 2rem; padding-top: 1rem;
    border-top: 0.5px solid var(--color-border-tertiary);">
    <button id="btn-prev" onclick="navigate(-1)" style="flex:1; opacity: 0.4; pointer-events: none;">Previous</button>
    <button id="btn-next" onclick="navigate(1)" style="flex:1;">Next section</button>
  </div>

  <!-- Export button (shown on last section) -->
  <div id="export-area" style="display:none; margin-top: 1.5rem;">
    <button onclick="exportBrief()" style="width: 100%; padding: 12px; font-weight: 500;
      background: #534AB7; color: #fff; border: none; border-radius: var(--border-radius-md);
      cursor: pointer;">Generate context brief ↗</button>
  </div>
</div>
```

Build the sections array in JavaScript with the data from the tables above, then
generate the HTML dynamically. Use `sendPrompt()` in the export function.
