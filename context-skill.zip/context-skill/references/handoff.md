# Handoff to Skill-Creator — Reference

This file contains the summary format, confirmation gate logic, change handling rules,
and the handoff instruction for passing the compiled brief to the skill-creator.

---

## 1. Skill summary format

Generate a concise summary from the compiled brief. Keep under 300 words.

### Structure

```
**Skill name:** [kebab-case suggestion based on purpose, e.g. "weekly-content-calendar"]

**In a nutshell:** [One sentence: "This skill takes [input] and produces [output]
for [user], following [key process/standard]."]

**What it does:**
- [3-5 bullets, one sentence each, plain language, from sections 1, 4, 5]

**What it needs:**
- [2-3 bullets listing inputs from section 3]

**What it produces:**
- [2-3 bullets describing output from section 4]

**Key rules:**
- [2-4 bullets, most important standards/constraints from sections 5.2 and 6]

**Known limitations:**
- [1-3 bullets from section 9 gaps. If none: "No significant gaps — the context
  brief is comprehensive."]

**Domain:** [Domain(s) and complexity in one line, e.g. "Finance (CIMA/IFRS) — Moderate"]
```

### Presentation

Present in chat with this framing:

"Here's a quick summary of the skill we're about to build. Have a read and let me
know if this looks right — or if anything needs adjusting before I send it to the
skill-creator."

[summary]

"Does this look right? If anything's off or missing, let me know and I'll update
the brief before we proceed."

---

## 2. Confirmation gate

### User confirms
Triggers: "yes", "looks good", "correct", "send it", "go ahead", "that's right",
"perfect", "all good", "confirmed", or any clear affirmative.

Action: Proceed to handoff immediately.
Response: "Great — sending the full context brief to the skill-creator now. It has
everything needed to start building."

### User requests minor changes
Things like: name changes, wording tweaks, small additions or removals.

Action:
1. Apply change to compiled brief
2. Check cascade effects (change to inputs may affect workflow, tests, gaps)
3. Update suggested skill description if triggers/purpose affected
4. Regenerate test scenarios if inputs/outputs/process affected
5. Regenerate summary
6. Present updated summary, ask for confirmation again

Response: "Updated — I've [description of change]. Here's the revised summary:
[summary] Does this look right now?"

### User requests major changes
Fundamentally different purpose, inputs, or process.

Action (if patchable): Update brief, regenerate summary, confirm again.
Response: "That's a meaningful change but I can update the brief to reflect it.
[updated summary] Does this look right now?"

Action (if too fundamental): Suggest revisiting the context form.
Response: "That's a pretty fundamental shift — it'll affect [areas]. Rather than
patching and risking inconsistencies, I'd suggest we revisit [specific section]
of the context form. Want me to pull that section up?"

### Loop limit (3+ rounds)
Response: "We've made quite a few adjustments — it might be cleaner to do a quick
pass through the context form again with your updated thinking. Want me to pull it
up with your existing answers pre-filled?"

---

## 3. Handoff instruction

Prepend this to the compiled brief when sending to the skill-creator:

```
I've completed a structured context gathering process for a new skill. Below is the
full Skill Context Brief containing everything you need to build this skill.

The brief has 10 sections:
1. Skill Identity — what it does and who it's for
2. Trigger Specification — when it should activate, including a suggested description
3. Input Specification — what it receives, with structure details
4. Output Specification — what it produces, with success and failure criteria
5. Process and Workflow — steps, standards, and autonomy level
6. Constraints and Boundaries — hard limits and edge cases
7. Domain-Specific Context — specialised details for this domain
8. Success and Testing — how to verify it works, with suggested test cases
9. Gaps and Unknowns — what's still missing or unclear
10. Appendix — raw answers for reference

Please use this brief as your primary reference for building the skill. The suggested
skill description in section 2.3 is a starting point for the SKILL.md frontmatter.
The test scenarios in section 8.3 are ready to use for evaluation.

Where gaps are flagged in section 9, please make reasonable assumptions and state
them — or ask me if you need clarification.
```

---

## 4. Delivery

Send via `sendPrompt()`: handoff instruction + full compiled brief as a single message.

Also save the compiled brief as a .md file for the user to download.

### Post-handoff message

"The full context brief has been sent. Here's what happens next:

The skill-creator will use your brief to draft the SKILL.md file, including the
trigger description, instructions, and workflow. It will then generate test cases
based on the scenarios in your brief and run them to check quality.

You'll get to review the draft and test results before anything is finalised.
Your compiled brief is also saved as a file if you want to reference it later."

---

## 5. Edge cases

**User wants to skip summary:** Respect their choice. Send brief directly.
"Sent. The full brief is also saved as a file if you want to review it later."

**User wants to edit brief directly:** Point to the saved .md file.
"The compiled brief is saved as a markdown file — you can edit it directly and
paste it into a conversation with the skill-creator whenever you're ready."

**User wants to think about it:** Confirm the brief is saved.
"No rush. Your compiled brief is saved — you can come back anytime."

**User wants to restart:** Acknowledge without judgement.
"No problem. Want a fresh context form, or keep your existing answers and just
update the sections that need changing?"
